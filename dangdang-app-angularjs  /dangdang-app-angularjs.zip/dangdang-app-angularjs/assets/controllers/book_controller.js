app.controller('bookController',['$scope',function($scope){
  $scope.bookTypes = [
    {id:'ertong',name:'儿童',img:'http://img3x8.ddimg.cn/97/8/23812468-1_l_1.jpg',description:'当当网童书热销榜'},
    {id:'lishi',name:'历史',img:'http://img3x8.ddimg.cn/97/8/23812468-1_l_1.jpg',description:'当当网历史书热销榜'},
    {id:'dongman',name:'动漫',img:'http://img3x8.ddimg.cn/97/8/23812468-1_l_1.jpg',description:'当当网热销榜'},
    {id:'qingchunwenxue',name:'青春文学',img:'http://img3x8.ddimg.cn/97/8/23812468-1_l_1.jpg',description:'当当网热销榜'}
  ]
}])
